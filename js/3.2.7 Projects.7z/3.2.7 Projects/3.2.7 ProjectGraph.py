'''heading'''

import numpy as np
import matplotlib.pyplot as plt


# Get the income/age data from CSV
datafile = open('DataProject.csv','r')
data = datafile.readlines()

years=[]
deathrates=[]

for line in data[5:]: # Omit header lines
    year, rate = line.split(',')
    years.append(year)
    deathrates.append(rate[0:-1])


fig, ax  = plt.subplots(1, 1)
ax.plot(years, deathrates, 'go')
ax.set_title('Annual Rates of Homicide\nUSA')
ax.set_xlabel('Years')
ax.set_ylabel('DeathRates Average')

fig.show()